class ToolRegistry:
    def __init__(self):
        # Lưu trữ các hàm (công cụ) đã đăng ký
        self.tools = {}
 
    def register(self, func):
        """
        Decorator dùng để biến một hàm bình thường thành Tool.
        Cách dùng: Thêm @registry.register trước định nghĩa hàm.
        """
        self.tools[func.__name__] = func
        return func

    def get_all_functions(self):
        """Trả về danh sách các hàm để đưa cho Gemini API."""
        return list(self.tools.values())

    def execute(self, function_call):
        """
        Nhận yêu cầu gọi hàm từ Gemini, thực thi hàm thực tế và trả về kết quả.
        """
        func_name = function_call.name
        
        # Lấy danh sách các tham số (arguments) mà Gemini muốn truyền vào
        args = function_call.args
        
        if func_name in self.tools:
            print(f"⚙️ SDK đang tự động chạy hàm: {func_name}({args})")
            func = self.tools[func_name]
            
            try:
                # Gọi hàm Python thực tế (unpack dictionary args)
                result = func(**args)
                return str(result)
            except Exception as e:
                return f"Lỗi khi chạy hàm: {e}"
        else:
            return f"Lỗi: Không tìm thấy công cụ tên {func_name}"
