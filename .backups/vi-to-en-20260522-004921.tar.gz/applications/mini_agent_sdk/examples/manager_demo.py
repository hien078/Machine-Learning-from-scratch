import os
import sys
import time
from pathlib import Path

# Add project root to path so `from src...` works
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from dotenv import load_dotenv
from src.agent import Agent
from src.tools import ToolRegistry

# Load API Key
load_dotenv()
api_key = os.getenv("GEMINI_API_KEY")

# ==========================================
# 1. TẠO CÁC AGENT CẤP DƯỚI (NHÂN VIÊN)
# ==========================================
accountant = Agent(
    name="Kế Toán",
    role="Bạn là chuyên gia tài chính kế toán. Hãy trả lời các câu hỏi về tiền bạc, tính toán chi phí, thuế một cách chuyên nghiệp. Trả lời cực kỳ ngắn gọn.",
    api_key=api_key
)

developer = Agent(
    name="Lập Trình Viên",
    role="Bạn là lập trình viên Python. Nhiệm vụ của bạn là viết code theo yêu cầu. Chỉ trả về code, không giải thích dài dòng.",
    api_key=api_key
)

# ==========================================
# 2. CHẾ TẠO "CÔNG CỤ ỦY QUYỀN" CHO MANAGER
# ==========================================
registry = ToolRegistry()

@registry.register
def delegate_task(agent_role: str, task_description: str) -> str:
    """
    Sử dụng công cụ này để giao việc cho các nhân viên cấp dưới.
    agent_role bắt buộc phải là 'Ketoan' hoặc 'Dev'.
    task_description là mô tả chi tiết công việc cần giao.
    """
    print(f"\n   🔄 [Hệ Thống Phân Luồng]: Manager đang gọi {agent_role} để làm việc: '{task_description}'...")
    
    if agent_role == 'Ketoan':
        time.sleep(3) # Nghỉ 3 giây để tránh lỗi quá tải API
        result = accountant.ask(task_description)
        print(f"   👩‍💼 [Kế Toán trả lời ngầm]: {result}")
        return result
    elif agent_role == 'Dev':
        time.sleep(3) # Nghỉ 3 giây để tránh lỗi quá tải API
        result = developer.ask(task_description)
        print(f"   👨‍💻 [Dev trả lời ngầm]: {result}")
        return result
    else:
        return f"Lỗi: Không có nhân viên nào có vai trò {agent_role}."

# ==========================================
# 3. TẠO MANAGER AGENT (QUẢN LÝ)
# ==========================================
manager = Agent(
    name="Quản Lý",
    role="Bạn là Quản lý dự án. Bạn KHÔNG BAO GIỜ tự giải quyết công việc. Nếu khách hàng hỏi về tiền/tài chính, hãy dùng công cụ delegate_task giao cho 'Ketoan'. Nếu hỏi về code/phần mềm, hãy giao cho 'Dev'. Sau khi nhận được kết quả từ nhân viên, hãy báo cáo lại cho khách hàng một cách lịch sự.",
    api_key=api_key,
    tools=registry.get_all_functions(),
    tool_registry=registry
)

# ==========================================
# 4. CHẠY THỬ NGHIỆM THỰC TẾ
# ==========================================
print("\n🏢 CÔNG TY AI BẮT ĐẦU HOẠT ĐỘNG")
print("=" * 60)

# Kịch bản 1: Yêu cầu code
request_1 = "Viết cho tôi một hàm Python để tính tổng 2 số nhé."
print(f"👤 [Khách Hàng]: {request_1}")
final_reply_1 = manager.ask(request_1)
print(f"\n👔 [Quản Lý trả lời Khách]:\n{final_reply_1}")

print("\n" + "-" * 60 + "\n")
print("⏳ (Tạm nghỉ 10 giây để tránh bị Google API block vì gửi quá nhanh...)")
time.sleep(10)

# Kịch bản 2: Yêu cầu tính toán tiền bạc
request_2 = "Tôi có 100 triệu, nếu gửi ngân hàng lãi suất 6%/năm thì sau 1 năm tôi có bao nhiêu tiền lãi?"
print(f"👤 [Khách Hàng]: {request_2}")
final_reply_2 = manager.ask(request_2)
print(f"\n👔 [Quản Lý trả lời Khách]:\n{final_reply_2}")

print("=" * 60)
