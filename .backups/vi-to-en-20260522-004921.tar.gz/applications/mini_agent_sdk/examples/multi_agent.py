import os
import sys
import time
from pathlib import Path

# Add project root to path so `from src...` works
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from dotenv import load_dotenv
from src.agent import Agent
from src.tools import ToolRegistry

# Load API Key
load_dotenv()
api_key = os.getenv("GEMINI_API_KEY")

# 1. Khởi tạo kho Công cụ (Tool)
registry = ToolRegistry()

@registry.register
def calculate_tax(salary: int) -> int:
    """Công cụ dùng để tính thuế thu nhập. Bất cứ khi nào cần tính thuế, phải gọi hàm này. Thuế mặc định là 10% tổng lương."""
    return int(salary * 0.10)

# 2. Tạo Agent 1: Kế toán (Được trang bị công cụ tính thuế)
accountant = Agent(
    name="Kế Toán",
    role="Bạn là một nhân viên kế toán nguyên tắc. Bất cứ khi nào sếp hỏi về thuế, bạn bắt buộc phải dùng công cụ calculate_tax để tính, không được tự nhẩm. Trả lời lịch sự và ngắn gọn.",
    api_key=api_key,
    tools=registry.get_all_functions(),
    tool_registry=registry
)

# 3. Tạo Agent 2: Giám đốc (Không có công cụ, chỉ biết ra lệnh)
boss = Agent(
    name="Giám Đốc",
    role="Bạn là một giám đốc khó tính. Bạn hãy yêu cầu kế toán tính thuế thu nhập cho một nhân viên. Bạn tự bịa ra tên nhân viên và mức lương (ví dụ 15 triệu, 20 triệu...). Đặt câu hỏi ngắn gọn.",
    api_key=api_key
)

# 4. KỊCH BẢN: Cho 2 Agent nói chuyện với nhau!
print("\n🎬 BẮT ĐẦU CUỘC HỌP")
print("=" * 50)

# Lời mở đầu của Sếp (Bắt đầu cuộc trò chuyện)
boss_message = boss.ask("Hãy ra lệnh cho kế toán tính thuế cho nhân viên mới đi.")
print(f"👔 [Giám Đốc]: {boss_message}")
time.sleep(2) # Dừng 2 giây cho giống người chat

# Kế toán nghe Sếp hỏi, sẽ tự động phân tích và dùng Tool calculate_tax
accountant_reply = accountant.ask(boss_message)
print(f"\n👩‍💼 [Kế Toán]: {accountant_reply}")
time.sleep(5)

# Sếp nghe kế toán báo cáo, đưa ra quyết định duyệt
final_decision = boss.ask(f"Kế toán vừa trả lời: '{accountant_reply}'. Hãy chốt lại và bảo cô ấy đi chuyển khoản.")
print(f"\n👔 [Giám Đốc]: {final_decision}")
print("=" * 50)
