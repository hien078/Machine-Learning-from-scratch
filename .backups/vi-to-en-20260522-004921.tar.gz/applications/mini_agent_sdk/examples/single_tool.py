import os
import sys
from pathlib import Path

# Add project root to path so `from src...` works
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from dotenv import load_dotenv
from google import genai
from src.tools import ToolRegistry

# 1. Khởi tạo Kho công cụ (Tool Registry)
registry = ToolRegistry()

# 2. Tạo một công cụ (Tool) và đăng ký nó
@registry.register
def get_weather(location: str) -> str:
    """Hàm này trả về thời tiết hiện tại của một địa điểm."""
    # Trong thực tế, bạn sẽ gọi API thời tiết (như OpenWeather). Ở đây ta làm giả lập.
    if "Hà Nội" in location:
        return "Trời mưa nhỏ, 22 độ C."
    elif "Hồ Chí Minh" in location:
        return "Nắng nóng, 34 độ C."
    return "Không có dữ liệu thời tiết cho khu vực này."

# 3. Kết nối với Bộ não (Gemini)
load_dotenv()
api_key = os.getenv("GEMINI_API_KEY")
client = genai.Client(api_key=api_key)

print("✅ Đã khởi tạo SDK và kết nối Gemini.")

# 4. Thử thách AI
prompt = "Thời tiết ở Hà Nội hôm nay thế nào?"
print(f"\n👤 Người dùng hỏi: {prompt}")

# Gửi yêu cầu và KÈM THEO danh sách công cụ
response = client.models.generate_content(
    model='gemini-2.5-flash',
    contents=prompt,
    config={'tools': registry.get_all_functions()}
)

# 5. Kiểm tra xem Gemini có muốn xài tool không
if response.function_calls:
    print("\n🧠 Gemini nhận ra nó cần xem thời tiết, nên nó yêu cầu dùng Tool!")
    
    for function_call in response.function_calls:
        print(f"  -> Gemini muốn gọi hàm: {function_call.name} với tham số {function_call.args}")
        
        # SDK của chúng ta tiến hành chạy hàm thực tế
        tool_result = registry.execute(function_call)
        print(f"  -> Kết quả thu được từ hàm: {tool_result}")
else:
    print("\n🤖 Gemini trả lời thẳng (không xài tool):")
    print(response.text)
