import os
from dotenv import load_dotenv
from google import genai

# Load biến môi trường từ file .env
load_dotenv()

# Lấy API Key
api_key = os.getenv("GEMINI_API_KEY")

if not api_key or api_key == "your_api_key_here":
    print("❌ Lỗi: Bạn chưa nhập GEMINI_API_KEY vào file .env!")
    exit(1)

print("✅ Đã tìm thấy API Key. Đang kết nối với Gemini...")

try:
    # Khởi tạo client kết nối với Gemini
    client = genai.Client(api_key=api_key)
    
    # Gửi câu hỏi đầu tiên tới model gemini-2.5-flash (nhẹ, nhanh, miễn phí)
    response = client.models.generate_content(
        model='gemini-2.5-flash',
        contents='Xin chào, bạn có thể nói 1 câu ngắn bằng tiếng Việt không?'
    )
    
    print("\n🤖 Gemini trả lời:")
    print("-" * 20)
    print(response.text)
    print("-" * 20)
    print("\n🎉 Thành công! Chúng ta đã kết nối được với 'Bộ não' của Agent.")

except Exception as e:
    print(f"\n❌ Lỗi kết nối: {e}")
