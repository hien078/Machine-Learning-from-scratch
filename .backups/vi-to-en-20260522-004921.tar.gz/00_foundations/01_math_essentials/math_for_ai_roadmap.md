# Toán cho AI/ML — Lộ trình theo mức độ cần thiết thực tế

> Xếp hạng theo **tần suất bạn thực sự dùng** khi làm AI/ML hiện đại (2026), không theo độ "khó" hay "đẹp" toán học.
> Mọi ký hiệu toán dùng Unicode (∑ ∫ ∂ ∇ → ≈), không dùng LaTeX.

---

## Mục lục

1. [Cách dùng tài liệu](#cách-dùng-tài-liệu)
2. [Bảng xếp hạng nhanh](#bảng-xếp-hạng-nhanh)
3. [Phân nhóm theo lộ trình](#phân-nhóm-theo-lộ-trình)
4. Chi tiết từng mảng:
   - [1. Đại số tuyến tính](#1-đại-số-tuyến-tính-linear-algebra)
   - [2. Giải tích nhiều biến](#2-giải-tích-nhiều-biến-multivariable-calculus)
   - [3. Xác suất & Thống kê](#3-xác-suất--thống-kê-probability--statistics)
   - [4. Tối ưu](#4-tối-ưu-optimization)
   - [5. Lý thuyết thông tin](#5-lý-thuyết-thông-tin-information-theory)
   - [6. Phương pháp số](#6-phương-pháp-số-numerical-methods)
   - [7. Toán rời rạc & Đồ thị](#7-toán-rời-rạc--đồ-thị-discrete-math--graph-theory)
   - [8. Phương trình vi phân](#8-phương-trình-vi-phân-differential-equations)
   - [9. Giải tích hàm](#9-giải-tích-hàm-functional-analysis)
   - [10. Hình học vi phân & Tô-pô](#10-hình-học-vi-phân--tô-pô-differential-geometry--topology)
   - [11. Đại số trừu tượng](#11-đại-số-trừu-tượng-abstract-algebra)
   - [12. Lý thuyết độ đo](#12-lý-thuyết-độ-đo-measure-theory)
   - [13. Toán cho kỷ nguyên LLM (2024-2026)](#13-toán-cho-kỷ-nguyên-llm-2024-2026)
5. [Toán ứng dụng "ngoài bảng" — đáng học sau khi vững nền](#toán-ứng-dụng-ngoài-bảng)
6. [Bẫy meta khi học toán cho AI](#bẫy-meta-khi-học-toán-cho-ai)
7. [Lộ trình 12 tháng đề xuất (3 path)](#lộ-trình-12-tháng-đề-xuất)
8. [Glossary VIE-EN](#glossary-vie-en)

---

## Cách dùng tài liệu

- **Không đọc tuần tự.** Xác định mục tiêu (engineer / research / một subfield cụ thể), rồi chỉ học chiều sâu mảng cần.
- **Học qua dự án, không qua sách.** Mỗi mảng đều có "tự kiểm" — nếu không làm được nghĩa là chưa đủ.
- **Use it or lose it.** Học mảng (10)(11)(12) khi chưa có project áp dụng = quên sạch sau 6 tháng.
- **"Đủ" là khái niệm tương đối.** Đủ cho engineer ≠ đủ cho research scientist ≠ đủ cho theory researcher.

---

## Bảng xếp hạng nhanh

| # | Mảng | Tần suất dùng | Độ ưu tiên | Học qua | Gặp ở đâu nhiều nhất |
|---|---|---|---|---|---|
| 1 | Đại số tuyến tính | Hàng ngày | 🔴 Phải có | Code + sách | Mọi mô hình |
| 2 | Calculus nhiều biến | Hàng ngày | 🔴 Phải có | Backprop from scratch | Training |
| 3 | Xác suất & Thống kê | Hàng tuần | 🔴 Phải có | Implement distribution | Loss, generative, eval |
| 4 | Tối ưu | Hàng tuần | 🔴 Phải có | Implement optimizer | Mọi training loop |
| 5 | Lý thuyết thông tin | Thường xuyên | 🟠 Sớm muộn | Cross-entropy, KL từ đầu | Loss, VAE, contrastive |
| 6 | Phương pháp số | Khi debug | 🟠 Sớm muộn | Stability tricks | FP16, softmax, log-space |
| 7 | Toán rời rạc & Đồ thị | Theo dự án | 🟠 Sớm muộn | Algorithm | GNN, attention, search |
| 8 | Phương trình vi phân | Theo subfield | 🟡 Theo nhu cầu | Neural ODE/SDE | Diffusion, flow |
| 9 | Giải tích hàm | Theo subfield | 🟡 Theo nhu cầu | Kernel, GP | SVM, GP, theory |
| 10 | Hình học vi phân & Tô-pô | Theo subfield | 🟡 Theo nhu cầu | Manifold paper | Geometric DL, hyperbolic embedding |
| 11 | Đại số trừu tượng | Niche | ⚪ Tùy chọn | Group-equivariant net | Sciences ML, physics |
| 12 | Lý thuyết độ đo | Rất hiếm | ⚪ Tùy chọn | Đọc paper rigorous | Pure theory |
| 13 | Toán cho kỷ nguyên LLM | Hàng tuần (LLM era) | 🟠 Combo của 1-7 | FlashAttention/Mamba/SSM | LLM train, serve, align |

> Section #13 không phải toán mới — là combo (1)(2)(3)(4)(6) áp dụng vào kiến trúc LLM 2024-2026. Tách ra vì engineer/researcher 2026 dùng hàng ngày.

---

## Phân nhóm theo lộ trình

```
🔴 PHẢI CÓ NGAY (1-4): không có thì không đọc nổi paper, không train nổi mô hình.
🟠 SỚM MUỘN CŨNG CẦN (5-7): gặp liên tục khi debug + đọc paper hiện đại.
🟡 THEO NHU CẦU (8-10): chỉ học khi subfield đòi hỏi.
⚪ TÙY CHỌN (11-12): pure research / niche cụ thể.
🟠 LLM ERA (13): combo của 🔴 + 🟠 áp dụng vào LLM stack.
```

**Nguyên tắc:** đừng học mảng cao hơn khi mảng thấp hơn còn lủng. Học (10) Differential Geometry trước khi vững (2) Calculus = mất thời gian vô ích.

---

## 1. Đại số tuyến tính (Linear Algebra)

### Vì sao là #1
Mọi dữ liệu trong AI = tensor (mở rộng của ma trận). Mọi layer của neural network = một phép biến đổi tuyến tính + một hàm phi tuyến. Hiểu đại số tuyến tính = hiểu xương sống của deep learning.

### Chủ đề lõi (must-know)

| Chủ đề | Tại sao cần |
|---|---|
| Vector, không gian vector | Embedding, feature space |
| Tích vô hướng (dot product), tích ngoài (outer product) | Similarity, attention |
| Ma trận, matmul, chuyển vị | Forward pass = matmul chain |
| Rank, kernel, image, không gian con | Low-rank, LoRA, bottleneck |
| Định thức, vết (trace) | Jacobian, determinant trong normalizing flow |
| Trị riêng (eigenvalue), vector riêng | PCA, spectral methods, ổn định Hessian |
| Phân tích giá trị kỳ dị (SVD) | PCA, low-rank approx, recommendation |
| Norm: L1, L2, L∞, Frobenius, nuclear, spectral | Regularization, weight decay |
| Ma trận đối xứng, PSD/PD | Covariance, Hessian, kernel |
| Phép chiếu, trực giao | Gram-Schmidt, QR, orthogonal init |
| Tích Kronecker, tích Hadamard | Efficient computation |
| Phân rã LU, QR, Cholesky | Giải hệ phương trình, sampling |

### Ứng dụng cụ thể trong AI

- **Forward pass:** y = σ(Wx + b) — chỉ là matmul + bias + phi tuyến.
- **Attention:** softmax(QKᵀ/√d)V — toàn phép tuyến tính.
- **PCA:** chéo hóa ma trận hiệp phương sai = SVD.
- **LoRA:** ΔW ≈ BA với rank(BA) ≪ rank(W) — phân rã low-rank.
- **Batch Normalization:** whitening = phép chiếu trên không gian con.
- **Word/Sentence Embedding:** điểm trong không gian R^d.
- **Graph Neural Network:** Laplacian L = D − A là ma trận đại số tuyến tính.

### Tài liệu khuyên dùng

- **Sách nền:** Gilbert Strang — "Introduction to Linear Algebra" (đọc dễ, có khóa MIT 18.06).
- **Sách rigorous:** Sheldon Axler — "Linear Algebra Done Right" (không dùng định thức).
- **Cho ML:** Chương 2 của "Mathematics for Machine Learning" (Deisenroth, Faisal, Ong) — free PDF.
- **Tham khảo nâng cao:** Trefethen & Bau — "Numerical Linear Algebra".

### Tự kiểm

- [ ] Tính SVD bằng tay cho ma trận 2×2.
- [ ] Giải thích vì sao attention chia √d (gợi ý: variance của dot product).
- [ ] Chứng minh cov matrix luôn PSD.
- [ ] Implement PCA bằng NumPy không dùng `np.linalg.svd` (dùng power iteration).
- [ ] Vì sao LoRA chỉ train rank r ≪ d mà vẫn work?

### Bẫy thường gặp

- Nhầm rank với dimension.
- Quên Aᵀ A khác A Aᵀ.
- Tưởng eigenvalue luôn thực — chỉ đúng cho ma trận đối xứng/Hermitian.
- Nhầm "trực giao" (orthogonal) và "trực chuẩn" (orthonormal).

---

## 2. Giải tích nhiều biến (Multivariable Calculus)

### Vì sao là #2
Mọi training = tối ưu một hàm loss theo hàng triệu/tỷ tham số. Backpropagation = chain rule áp dụng trên đồ thị tính toán. Không có calculus = không hiểu vì sao mô hình học được.

### Chủ đề lõi

| Chủ đề | Tại sao cần |
|---|---|
| Đạo hàm riêng (partial derivative) | Mọi gradient component |
| Gradient ∇f | Hướng tăng nhanh nhất của loss |
| Jacobian J | Đạo hàm vector → vector, backprop qua layer |
| Hessian H | Curvature, second-order method, sharpness |
| Chain rule (1 biến, nhiều biến) | Backpropagation |
| Đạo hàm theo ma trận / vector | Tính gradient của loss theo W |
| Khai triển Taylor | Linearization, second-order approx |
| Tích phân nhiều biến | Marginalization trong xác suất |
| Định lý hàm ẩn (Implicit function theorem) | Implicit layer, equilibrium model |
| Quy tắc Leibniz | Đạo hàm dưới dấu tích phân, reparameterization |

### Ứng dụng cụ thể

- **Backpropagation:** chain rule tổng quát hóa cho composition của hàm.
- **Reverse-mode autodiff:** lý do PyTorch/JAX nhanh — tính Jacobian-vector product hiệu quả.
- **Reparameterization trick (VAE):** z = μ + σ ⊙ ε, cho phép gradient flow qua sample.
- **Sharpness-aware minimization (SAM):** dùng Hessian/curvature.
- **Natural gradient:** F⁻¹ ∇L với F là Fisher information matrix.
- **Score matching:** ∇_x log p(x) — gradient của log-density.

### Tài liệu

- **Sách nền:** Stewart — "Multivariable Calculus" (phổ thông, dễ).
- **Cho ML:** Chương 5 của "Mathematics for Machine Learning".
- **Matrix calculus:** "The Matrix Cookbook" (Petersen & Pedersen) — tra cứu công thức.
- **Autodiff:** "Automatic Differentiation in Machine Learning: a Survey" (Baydin et al.).

### Tự kiểm

- [ ] Tính ∂(xᵀAx)/∂x bằng tay.
- [ ] Derive gradient của cross-entropy loss qua softmax.
- [ ] Implement backprop từ đầu cho một MLP 2 lớp bằng NumPy.
- [ ] Giải thích reparameterization trick: vì sao cần thiết cho VAE?
- [ ] Vẽ một computation graph và tính reverse-mode autodiff bằng tay.

### Bẫy thường gặp

- Nhầm gradient là vô hướng — gradient luôn là vector.
- Quên transpose khi đạo hàm theo ma trận.
- Tưởng Hessian luôn tính được — với mô hình lớn, Hessian không lưu nổi.
- Nhầm Jacobian-vector product (forward-mode) với vector-Jacobian product (reverse-mode).

---

## 3. Xác suất & Thống kê (Probability & Statistics)

### Vì sao là #3
ML = học từ dữ liệu = học phân phối. Mọi loss đều có diễn giải xác suất. Generative model = học p(x). Bayesian DL, uncertainty, A/B test — đều cần.

### Chủ đề lõi

| Chủ đề | Tại sao cần |
|---|---|
| Biến ngẫu nhiên rời rạc, liên tục | Mọi mô hình stochastic |
| Phân phối: Bernoulli, Categorical, Gaussian, Poisson, Exponential, Beta, Dirichlet | Likelihood, prior |
| Kỳ vọng, phương sai, covariance | Loss, regularization |
| Joint, marginal, conditional | Bayes, graphical model |
| Định lý Bayes | MAP, Bayesian inference |
| MLE, MAP, EM | Học tham số |
| Định lý giới hạn trung tâm (CLT) | Vì sao Gaussian phổ biến |
| Law of large numbers | SGD hội tụ |
| Sampling: rejection, importance, MCMC, Gibbs | Bayesian inference, diffusion |
| Variational inference, ELBO | VAE, biến phân |
| Hypothesis testing, p-value, confidence interval | Evaluate model, A/B |
| Concentration inequalities (Markov, Chebyshev, Hoeffding) | Generalization bound |
| Phân phối mũ (exponential family) | Hiểu chung framework |

### Ứng dụng cụ thể

- **Cross-entropy loss:** −E[log p(y|x)] = negative log-likelihood.
- **VAE:** maximize ELBO = log p(x) − KL(q(z|x) || p(z)).
- **Diffusion model:** học gradient của log-density (score) tại nhiều mức nhiễu.
- **Bayesian Neural Network:** đặt prior trên weights, posterior qua VI hoặc MCMC.
- **Uncertainty estimation:** epistemic vs aleatoric uncertainty.
- **Active learning:** chọn sample có entropy cao nhất.
- **GAN:** không trực tiếp xác suất nhưng cuối cùng tối ưu một dạng divergence.
- **Reinforcement learning:** policy = distribution over actions.

### Tài liệu

- **Sách nền:** Wasserman — "All of Statistics" (cô đọng, đủ cho ML).
- **Sách ML:** Bishop — "Pattern Recognition and Machine Learning" (PRML, kinh điển).
- **Bayesian:** Gelman — "Bayesian Data Analysis".
- **Sâu hơn:** Murphy — "Probabilistic Machine Learning: Advanced Topics".
- **Cho người mới:** Blitzstein — "Introduction to Probability".

### Tự kiểm

- [ ] Derive cross-entropy = negative log-likelihood của Bernoulli/Categorical.
- [ ] Derive ELBO của VAE bằng hai cách: (a) từ KL(q∥posterior) ≥ 0, (b) từ Jensen inequality. Cách (a) cho thấy gap chính xác = KL.
- [ ] Giải thích vì sao log-likelihood thường tốt hơn likelihood (numerical).
- [ ] Cho mô hình Gaussian, tính MLE của μ và σ² bằng tay.
- [ ] Implement Gibbs sampling cho một mô hình đơn giản.
- [ ] Phân biệt: epistemic uncertainty vs aleatoric uncertainty.

### Bẫy thường gặp

- Nhầm p(A|B) với p(B|A) — base rate fallacy.
- Quên Jacobian khi đổi biến (change of variable).
- Nhầm posterior với likelihood.
- Tưởng MLE và MAP luôn cho cùng kết quả (chỉ khi prior uniform).
- Quên rằng KL không đối xứng: KL(p||q) ≠ KL(q||p).

---

## 4. Tối ưu (Optimization)

### Vì sao là #4
Training = bài toán tối ưu. Hiểu optimizer = hiểu vì sao Adam thường tốt hơn SGD, vì sao learning rate quan trọng, vì sao mô hình bị kẹt ở saddle point.

### Chủ đề lõi

| Chủ đề | Tại sao cần |
|---|---|
| Convex vs non-convex | DL là non-convex, hiểu khác biệt |
| Gradient descent, SGD | Optimizer cơ bản |
| Momentum, Nesterov | Tăng tốc, vượt local minima |
| Adaptive methods: AdaGrad, RMSProp, Adam, AdamW | Optimizer hiện đại |
| Learning rate schedule | Warmup, cosine decay, vital cho LLM |
| Second-order: Newton, quasi-Newton (L-BFGS) | Khi nào dùng được |
| Constrained optimization, Lagrange, KKT | SVM, RLHF |
| Duality | Hiểu sâu SVM, convex problems |
| Stochastic optimization, variance reduction | SGD analysis |
| Convergence analysis (rate, bound) | Đọc paper optimization |
| Sharpness, flatness, generalization | Lý thuyết generalization |
| Trust region, proximal methods | TRPO, RL |

### Ứng dụng cụ thể

- **SGD with momentum:** v ← βv + ∇L; θ ← θ − ηv. Mọi mô hình lớn vẫn dùng.
- **Adam:** kết hợp momentum + adaptive lr theo từng tham số. Default cho NLP/CV.
- **AdamW:** Adam + decoupled weight decay. Default cho LLM training.
- **Learning rate warmup:** lr tăng tuyến tính trong N step đầu rồi decay. Vital cho transformer.
- **Gradient clipping:** clip norm để tránh exploding gradient.
- **TRPO/PPO:** trust region trong RL, không cho policy đổi quá nhiều mỗi bước.
- **DPO (Direct Preference Optimization):** tối ưu trực tiếp preference qua reward implicit, tránh tách rời reward model + PPO. Không phải lúc nào cũng vượt RLHF (PPO/GRPO) — vẫn đang tranh luận, mỗi cái có sweet spot riêng.
- **GRPO (Group Relative Policy Optimization):** loại RLHF không cần value network, ước lượng advantage qua group reward. DeepSeek/R1 chuỗi reasoning model dùng.
- **Muon, SOAP, Shampoo:** optimizer dùng curvature dạng matrix (2nd-moment matrix-valued). 2024-2026 chứng minh vượt AdamW trên một số setup LLM, vẫn đang ra paper.

### Tài liệu

- **Convex:** Boyd & Vandenberghe — "Convex Optimization" (free PDF, kinh điển).
- **Non-convex / ML:** Bottou, Curtis, Nocedal — "Optimization Methods for Large-Scale ML" (survey).
- **Sách giáo trình:** Nocedal & Wright — "Numerical Optimization".
- **DL specific:** Goodfellow et al. — "Deep Learning" chương 8.

### Tự kiểm

- [ ] Implement SGD, momentum, Adam from scratch.
- [ ] Derive update rule của Adam từ định nghĩa.
- [ ] Giải thích bias correction trong Adam: vì sao chia (1−β^t).
- [ ] Vì sao decoupled weight decay khác L2 regularization trong Adam?
- [ ] Vẽ loss landscape của một bài toán convex vs non-convex.
- [ ] Giải bài toán SVM bằng KKT condition bằng tay (case 2D).

### Bẫy thường gặp

- Tưởng Adam luôn tốt hơn SGD — không, SGD+momentum vẫn vô địch cho CV trong nhiều case.
- Quên zero gradient (`optimizer.zero_grad()`).
- Đặt learning rate quá cao → loss spike / NaN.
- Không dùng warmup khi train transformer → loss divergence.
- Nhầm batch size lớn = train nhanh — thực ra cần scale lr theo √batch hoặc tuyến tính.

---

## 5. Lý thuyết thông tin (Information Theory)

### Vì sao quan trọng
Hầu hết loss của classification và generative model có gốc từ information theory. Hiểu sâu cross-entropy, KL, MI = đọc paper hiện đại fluent hơn rất nhiều.

### Chủ đề lõi

| Chủ đề | Tại sao cần |
|---|---|
| Entropy H(X) | Đo độ bất định |
| Joint, conditional, mutual entropy | Đo phụ thuộc |
| Cross-entropy H(p,q) | Loss của classification |
| KL divergence D_KL(p∥q) | VAE, variational inference, distillation |
| Mutual information I(X;Y) | Contrastive learning, InfoMax |
| Jensen-Shannon divergence | GAN |
| Rate-distortion theory | VAE bottleneck, compression |
| Channel capacity | Information bottleneck principle |
| MDL, Kolmogorov complexity | Lý thuyết Occam's razor |
| f-divergence (tổng quát hóa) | f-GAN, advanced |

### Ứng dụng cụ thể

- **Cross-entropy loss:** loss của mọi classification = H(p_true, p_model).
- **KL trong VAE:** ELBO = E[log p(x|z)] − KL(q(z|x) ∥ p(z)).
- **Knowledge distillation:** student học từ teacher qua KL trên softmax output.
- **InfoNCE (Contrastive learning):** lower bound của mutual information → SimCLR, CLIP.
- **Information Bottleneck:** học representation Z sao cho I(X;Z) min và I(Y;Z) max.
- **Perplexity:** exp(cross-entropy) — metric chuẩn cho language model.
- **β-VAE:** thêm hệ số β trước KL để kiểm soát disentanglement.

### Tài liệu

- **Kinh điển:** David MacKay — "Information Theory, Inference, and Learning Algorithms" (free PDF, vô địch).
- **Sách giáo trình:** Cover & Thomas — "Elements of Information Theory".
- **ML focused:** Tishby's papers về Information Bottleneck.
- **Modern:** Poole et al. (2019) "On Variational Bounds of Mutual Information".

### Tự kiểm

- [ ] Derive cross-entropy từ định nghĩa entropy.
- [ ] Tính KL giữa hai Gaussian bằng tay.
- [ ] Giải thích InfoNCE loss đang ước lượng cái gì.
- [ ] Vì sao KL không đối xứng quan trọng trong VAE? (forward vs reverse KL)
- [ ] Implement perplexity cho một language model.
- [ ] Phân biệt: H(X) vs H(X|Y) vs I(X;Y).

### Bẫy thường gặp

- Quên rằng KL ≥ 0 và = 0 ⇔ p = q a.e.
- Nhầm forward KL (mode-covering) với reverse KL (mode-seeking).
- Tưởng MI có thể ước lượng dễ — thực ra cực khó, cần lower bound (MINE, InfoNCE).
- Quên log-base: log_2 (bit) vs log_e (nat).

---

## 6. Phương pháp số (Numerical Methods)

### Vì sao quan trọng
Mọi tính toán ML đều trên máy = số float hữu hạn. Hiểu floating-point = hiểu vì sao loss bị NaN, vì sao FP16 train hỏng, vì sao softmax overflow.

### Chủ đề lõi

| Chủ đề | Tại sao cần |
|---|---|
| Biểu diễn floating-point (FP32, TF32, FP16, BF16, FP8 E4M3/E5M2) | Mixed precision training |
| Sai số làm tròn (round-off error) | Numerical stability |
| Ổn định số (numerical stability) | Tránh NaN/Inf |
| Số điều kiện (condition number) | Khi nào ma trận khó nghịch đảo |
| Log-space trick: logsumexp | Softmax numerically stable |
| Cancellation, catastrophic cancellation | Sai số khi trừ hai số gần nhau |
| Iterative methods: Jacobi, Gauss-Seidel, CG | Giải hệ tuyến tính lớn |
| Numerical integration, quadrature | Sampling, normalization |
| Power iteration, Lanczos | Eigenvalue lớn nhất |

### Ứng dụng cụ thể

- **Stable softmax:** softmax(x) = softmax(x − max(x)) để tránh overflow.
- **logsumexp:** log(Σ exp(x_i)) = max + log(Σ exp(x_i − max)).
- **Mixed precision (FP16/BF16/FP8):** train nhanh + ít memory. FP16 cần loss scaling vì range hẹp; BF16 default cho LLM (cùng exponent FP32); FP8 (H100/Blackwell) cần per-tensor/per-block scale + cẩn thận với softmax, layernorm vốn nhạy precision.
- **Gradient clipping:** clip norm để tránh exploding.
- **Layer normalization:** chia (x − μ) / √(σ² + ε), ε để tránh chia 0.
- **Stable cross-entropy:** kết hợp logsoftmax + NLLLoss thay vì softmax + log + NLL.

### Tài liệu

- **Sách kinh điển:** Trefethen & Bau — "Numerical Linear Algebra".
- **Sâu:** Higham — "Accuracy and Stability of Numerical Algorithms".
- **Practical:** "What Every Computer Scientist Should Know About Floating-Point Arithmetic" (Goldberg).
- **DL specific:** NVIDIA Mixed Precision training guide.

### Tự kiểm

- [ ] Vì sao softmax([1000, 1001, 1002]) overflow? Cách fix?
- [ ] Tính 1 + 1e-20 trong FP32 = ?
- [ ] Phân biệt FP16 vs BF16 vs FP8: range vs precision tradeoff, cái nào tốt cho training/inference? Vì sao?
- [ ] Implement logsumexp.
- [ ] Khi nào ma trận có condition number cao gây vấn đề?
- [ ] Vì sao loss spike khi train với FP16 không có loss scaling?

### Bẫy thường gặp

- Tưởng 0.1 + 0.2 = 0.3 (không, do binary float).
- Quên ε trong LayerNorm, BatchNorm, divisions.
- Train FP16 mà không loss scaling → underflow gradient.
- Subtract hai số gần nhau (catastrophic cancellation) → mất precision.
- Tưởng accuracy 4 chữ số đáng tin — trên FP32 nhiều phép ≈ 7 chữ số.

---

## 7. Toán rời rạc & Đồ thị (Discrete Math & Graph Theory)

### Vì sao quan trọng
Cấu trúc dữ liệu của nhiều mô hình hiện đại là đồ thị: GNN, attention (full graph), tokenization (BPE), search trong RL/planning, retrieval.

### Chủ đề lõi

| Chủ đề | Tại sao cần |
|---|---|
| Tập hợp, ánh xạ, quan hệ | Cơ bản |
| Tổ hợp, đếm | Combinatorial search |
| Đồ thị: undirected, directed, weighted | GNN, computation graph |
| Đường đi, chu trình, kết nối | Reachability, search |
| Cây, cây bao trùm | Decision tree, parsing |
| Đồ thị Laplacian L = D − A | Spectral GNN, manifold |
| Algorithm graph: BFS, DFS, Dijkstra, A* | Search, planning |
| Dynamic programming | RL value iteration, Viterbi |
| Độ phức tạp (Big-O) | Efficient algorithm |
| Hashing, locality-sensitive hashing | ANN search, retrieval |

### Ứng dụng cụ thể

- **Graph Neural Network (GNN):** message passing trên đồ thị.
- **Graph Attention (GAT):** attention weight giữa node láng giềng.
- **Transformer = GNN trên fully-connected graph:** mọi token "kết nối" mọi token khác.
- **Beam search, top-k sampling:** decoding trong NLP.
- **BPE tokenization:** greedy merge thường xuất hiện trong corpus.
- **Retrieval (ANN, HNSW, FAISS):** kNN trên embedding space, hashing.
- **MCTS (Monte Carlo Tree Search):** AlphaGo, AlphaZero.

### Tài liệu

- **Sách nền:** Rosen — "Discrete Mathematics and Its Applications".
- **Algorithm:** CLRS — "Introduction to Algorithms".
- **Graph specific:** Cormen chương graph, hoặc "Graph Representation Learning" (Hamilton).
- **GNN:** "A Comprehensive Survey on Graph Neural Networks" (Wu et al., 2020).

### Tự kiểm

- [ ] Implement GCN layer from scratch bằng NumPy.
- [ ] Viết Dijkstra/A* tự tay.
- [ ] Giải thích Viterbi algorithm (DP cho HMM decoding).
- [ ] Vẽ computation graph của một transformer block.
- [ ] Phân tích complexity của attention (O(n²)) và lý do cần linear attention.

### Bẫy thường gặp

- Nhầm tree với graph có chu trình.
- Implement GNN không normalize Laplacian → exploding.
- Beam search không phải optimal, chỉ heuristic.
- Nhầm directed vs undirected khi build adjacency matrix.

---

## 8. Phương trình vi phân (Differential Equations)

### Vì sao quan trọng (theo subfield)
Diffusion model, neural ODE, flow matching — hot trong generative AI 2026. Nếu nhắm generative model, đây là toán bắt buộc.

### Chủ đề lõi

| Chủ đề | Tại sao cần |
|---|---|
| ODE bậc 1, bậc 2 | Neural ODE |
| Hệ ODE tuyến tính | Linear dynamics |
| Phương pháp Euler, Runge-Kutta | ODE solver numerical |
| Stochastic differential equation (SDE) | Diffusion (score-based) |
| Itô calculus cơ bản | SDE manipulation |
| Fokker-Planck equation | Diffusion density evolution |
| Continuous-time flow | Flow matching, rectified flow |
| Probability flow ODE | Diffusion sampling (deterministic) |

### Ứng dụng cụ thể

- **Neural ODE:** dy/dt = f(y, t, θ), train bằng adjoint method.
- **Continuous Normalizing Flow:** áp dụng ODE để biến đổi distribution.
- **DDPM (Denoising Diffusion):** học reverse process của một chuỗi nhiễu (rời rạc).
- **Score-based generative model:** học score ∇_x log p_t(x) tại nhiều mức nhiễu, sample bằng SDE/ODE.
- **Flow Matching / Rectified Flow:** thay vì noise → data qua nhiều bước, học vector field thẳng.
- **Consistency models:** distillation của diffusion về 1-step.

### Tài liệu

- **ODE nền:** Strogatz — "Nonlinear Dynamics and Chaos".
- **SDE nền:** Øksendal — "Stochastic Differential Equations".
- **Diffusion model:** Yang Song's blog "Generative Modeling by Estimating Gradients of the Data Distribution".
- **Paper foundational:**
  - Neural ODE (Chen et al., 2018).
  - DDPM (Ho et al., 2020).
  - Score-based (Song & Ermon, 2019, 2021).
  - Flow Matching (Lipman et al., 2023).

### Tự kiểm

- [ ] Solve dy/dt = −ky bằng tay.
- [ ] Implement Euler solver cho Neural ODE.
- [ ] Derive ELBO của DDPM.
- [ ] Giải thích sự liên hệ giữa diffusion (rời rạc) và score-based SDE (liên tục).
- [ ] Implement DDPM sampling từ checkpoint cho trước.

### Bẫy thường gặp

- Nhầm forward và reverse process trong diffusion.
- Quên rằng SDE cần Itô integral, khác Riemann.
- Tưởng diffusion = VAE — về toán khác xa.
- Numerical solver không ổn định khi step size lớn.

---

## 9. Giải tích hàm (Functional Analysis)

### Vì sao quan trọng (theo subfield)
Gốc của kernel methods (SVM, GP). Ngày càng ít quan trọng với deep learning, nhưng vẫn nền tảng cho theory.

### Chủ đề lõi

| Chủ đề | Tại sao cần |
|---|---|
| Không gian Banach, Hilbert | Nền tảng |
| Inner product, norm, completeness | RKHS |
| Operator tuyến tính giữa không gian hàm | Kernel operator |
| Reproducing Kernel Hilbert Space (RKHS) | Kernel methods |
| Spectral theorem cho compact operator | Mercer's theorem |
| Fourier analysis cơ bản | Signal, Fourier features |

### Ứng dụng cụ thể

- **Kernel SVM:** maximize margin trong RKHS.
- **Gaussian Process:** distribution trên function, kernel = covariance.
- **Random Fourier Features:** xấp xỉ kernel bằng feature map ngẫu nhiên.
- **Neural Tangent Kernel (NTK):** wide NN tương đương kernel method.
- **Sinusoidal positional encoding:** Fourier basis trong transformer.
- **Implicit Neural Representation (NeRF, SIREN):** Fourier feature trong input.

### Tài liệu

- **Sách:** Kreyszig — "Introductory Functional Analysis with Applications".
- **Kernel methods:** Schölkopf & Smola — "Learning with Kernels".
- **GP:** Rasmussen & Williams — "Gaussian Processes for Machine Learning" (free PDF).
- **NTK:** Jacot et al. (2018) — "Neural Tangent Kernel".

### Tự kiểm

- [ ] Định nghĩa RKHS bằng reproducing property.
- [ ] Derive kernel SVM dual form.
- [ ] Implement Gaussian Process regression bằng NumPy.
- [ ] Tính NTK của một mạng 1 layer width-vô-hạn.

### Bẫy thường gặp

- Nhầm "kernel" trong ML (similarity function) với "kernel" trong linear algebra (null space).
- Cứ Hilbert là R^d — không, có thể là không gian hàm vô hạn chiều.
- GP scale O(n³) với n sample — không scalable cho dataset lớn.

---

## 10. Hình học vi phân & Tô-pô (Differential Geometry & Topology)

### Vì sao quan trọng (theo subfield)
Manifold learning, hyperbolic embedding, lý thuyết diffusion (score = gradient trên manifold), interpretability (loss landscape).

### Chủ đề lõi

| Chủ đề | Tại sao cần |
|---|---|
| Manifold, tangent space | Manifold hypothesis của data |
| Riemannian metric | Distance trên manifold |
| Geodesic | Đường đi ngắn nhất |
| Curvature, Ricci | Phân tích loss landscape |
| Exponential map, logarithm map | Optimization trên manifold |
| Fiber bundle | Equivariant network |
| Cohomology cơ bản | Topology of data |
| Persistent homology | Topological Data Analysis (TDA) |

### Ứng dụng cụ thể

- **Manifold hypothesis:** dữ liệu thực tế nằm trên một manifold low-dimensional trong không gian high-dim.
- **Hyperbolic embedding:** dùng cho tree/hierarchy data (Poincaré embedding).
- **Loss landscape geometry:** sharp vs flat minima → generalization.
- **Geometric Deep Learning:** Bronstein et al. — unify GNN, CNN, transformer qua geometry.
- **Manifold optimization:** Adam on Stiefel/Grassmann manifold cho orthogonal weight.
- **TDA cho ML:** persistence diagram làm feature.

### Tài liệu

- **Sách nền:** do Carmo — "Riemannian Geometry".
- **Cho ML:** Bronstein et al. — "Geometric Deep Learning: Grids, Groups, Graphs, Geodesics, and Gauges" (free book).
- **TDA:** Edelsbrunner & Harer — "Computational Topology".
- **Optimization on manifold:** Absil, Mahony, Sepulchre — "Optimization Algorithms on Matrix Manifolds".

### Tự kiểm

- [ ] Tính tangent space của sphere S² tại một điểm.
- [ ] Implement Poincaré embedding cho tree đơn giản.
- [ ] Giải thích flat minima hypothesis về mặt geometry.
- [ ] Derive exponential map trên sphere.

### Bẫy thường gặp

- Manifold learning ≠ Riemannian DL — hai concept gần nhưng khác.
- Tưởng mọi data nằm trên manifold đẹp — thực tế noise, không đều.
- Hyperbolic embedding khó train hơn Euclidean nhiều.

---

## 11. Đại số trừu tượng (Abstract Algebra)

### Vì sao quan trọng (niche)
Group-equivariant network: AlphaFold, vật lý ML, computer vision có đối xứng. Đẹp về mặt lý thuyết, niche về ứng dụng.

### Chủ đề lõi

| Chủ đề | Tại sao cần |
|---|---|
| Group, subgroup, normal subgroup | Đối xứng |
| Group action | Symmetry trong data |
| Representation theory | Equivariant layer |
| Lie group, Lie algebra | Continuous symmetry (rotation, translation) |
| Irreducible representation | Tensor field network, e3nn |
| Quotient group | Pose estimation |

### Ứng dụng cụ thể

- **Equivariant CNN:** group convolution thay normal convolution.
- **E(3)-equivariant network:** AlphaFold, dùng cho 3D molecule.
- **Tensor Field Network, e3nn:** equivariant cho rotation 3D.
- **Spherical CNN:** cho data trên sphere (climate, omnidirectional image).
- **SE(3)-Transformer:** transformer equivariant với rigid transformation.

### Tài liệu

- **Sách nền:** Dummit & Foote — "Abstract Algebra".
- **Representation theory:** Fulton & Harris — "Representation Theory".
- **Cho ML:** Bronstein et al. "Geometric Deep Learning" chương group.
- **Paper:** Cohen & Welling (2016) "Group Equivariant CNNs".

### Tự kiểm

- [ ] Liệt kê đối xứng của một square (D₄ group).
- [ ] Giải thích equivariant vs invariant.
- [ ] Implement một equivariant layer đơn giản cho rotation.

### Bẫy thường gặp

- Nhầm invariant với equivariant.
- Tưởng "thêm equivariance" luôn tốt — thực ra constrain network mạnh, có thể giảm capacity.

---

## 12. Lý thuyết độ đo (Measure Theory)

### Vì sao quan trọng (rất hiếm)
Chỉ cần khi đọc paper xác suất rigorous (vd: convergence proof, optimal transport theory). Không cần để làm AI/ML thực tế.

### Chủ đề lõi

| Chủ đề | Tại sao cần |
|---|---|
| σ-algebra | Định nghĩa probability rigorous |
| Measure | Generalization của xác suất |
| Lebesgue integral | Tích phân với function không Riemann-integrable |
| Radon-Nikodym derivative | Density giữa hai measure |
| Dominated convergence | Đổi limit và integral |
| Optimal transport, Wasserstein distance | WGAN, distribution matching |

### Ứng dụng cụ thể

- **Wasserstein distance:** dùng trong WGAN, optimal transport.
- **Radon-Nikodym:** chính là density p(x). Quan trọng khi đổi measure.
- **Convergence theorem:** dùng trong proof của paper theory.

### Tài liệu

- **Sách:** Folland — "Real Analysis".
- **Probability rigorous:** Billingsley — "Probability and Measure".
- **Optimal transport:** Villani — "Optimal Transport: Old and New" (rất khó).
- **Cho ML:** Peyré & Cuturi — "Computational Optimal Transport" (dễ hơn).

### Tự kiểm

- [ ] Định nghĩa σ-algebra.
- [ ] Phân biệt Riemann và Lebesgue integral.
- [ ] Hiểu được Wasserstein-1 = duality form (Kantorovich-Rubinstein).

### Bẫy thường gặp

- Học measure theory trước khi cần → quên sạch.
- Bị overwhelm bởi formalism.

---

## 13. Toán cho kỷ nguyên LLM (2024-2026)

### Vì sao tách riêng
Không phải mảng toán mới — là combo của (1)(2)(3)(4)(6) áp dụng vào kiến trúc LLM-era. Tách ra vì đây là nơi engineer/researcher 2026 thực sự gặp hàng ngày, và toán cần khác đáng kể với "ML cổ điển 2018".

### Chủ đề & toán nền cần

| Chủ đề | Toán nền | Vì sao |
|---|---|---|
| FlashAttention (v1/v2/v3) | (6) IO model, tiling, online softmax | Không phải toán mới, là re-engineer softmax cho HBM-aware |
| RoPE (Rotary Position Embedding) | (1) phép quay 2D / số phức | Rotation per-head theo position |
| ALiBi, YaRN, NTK-aware scaling | (1)(2) extrapolation theory | Long-context không cần train lại |
| Grouped/Multi-Query Attention | (1) tradeoff rank vs KV cache | Inference economics |
| Linear / sub-quadratic attention | (1)(9) kernel approximation | Performer, Hyena, RWKV |
| **State Space Models (S4, Mamba)** | (1)(8) discretize linear ODE: ḣ = Ah + Bx | Selective recurrence parallel-scannable; HiPPO theory |
| Mixture of Experts (MoE) | (3)(4) routing softmax + load-balance loss | Sparse compute scale-up |
| Quantization (GPTQ, AWQ, GGUF) | (1)(6) min ‖Wx − W_q x‖² calibration | Inference cost |
| Speculative / parallel decoding | (3) rejection sampling, distribution matching | Tốc độ decode 2-4× |
| Test-time compute (search, BoN, MCTS) | (3)(7) DP + Bayesian decision | Reasoning model (o1, R1) |
| Process Reward Model (PRM) | (3)(4) credit assignment per step | RL trên reasoning trace |
| Mechanistic interpretability | (1) SVD/superposition + (3) feature distribution | Circuit, SAE (sparse autoencoder) |
| RLHF / GRPO / DPO | (3)(4) KL-regularized policy optim | Alignment |

### Tài liệu
- **FlashAttention:** Dao et al. (2022, 2023, 2024) — đọc theo thứ tự v1→v3.
- **Mamba/SSM:** Gu & Dao (2023) "Mamba"; Gu (2023) thesis về S4 nếu muốn sâu.
- **Speculative decoding:** Leviathan et al. (2023); Chen et al. (2023) "Accelerating LLM Inference".
- **MoE:** Switch Transformer (Fedus et al., 2021); Mixtral paper.
- **Quantization:** GPTQ (Frantar et al., 2022); AWQ (Lin et al., 2023).
- **Interpretability:** Anthropic "A Mathematical Framework for Transformer Circuits" (Elhage et al., 2021).
- **RL alignment:** PPO (Schulman 2017); DPO (Rafailov 2023); GRPO (DeepSeekMath 2024).

### Tự kiểm
- [ ] Derive online softmax (running max + denominator) dùng trong FlashAttention.
- [ ] Implement RoPE bằng tay trên một attention head — verify quay đúng.
- [ ] Discretize ḣ = Ah + Bx bằng ZOH, derive recurrence form của Mamba selective scan.
- [ ] Giải thích rejection sampling trong speculative decoding: vì sao distribution của output không đổi.
- [ ] Phân biệt DPO loss và PPO loss — cái nào dùng reward model rõ ràng?
- [ ] Đọc 1 SAE paper, giải thích loss = reconstruction + L1 sparsity nghĩa là gì.

### Bẫy thường gặp
- Tưởng FlashAttention "exact" giống softmax thường — đúng về mặt giá trị, khác về thứ tự phép tính (numerical equivalent nhưng không bit-equal).
- Implement RoPE sai axis → attention thành noise.
- SSM discretization sai (Euler vs ZOH vs bilinear) → unstable.
- Quantization PTQ tốt trên benchmark nhưng hỏng long-tail input.
- Speculative decoding cài sai → output distribution lệch khỏi target model.
- Train DPO chỉ trên 1 epoch không đủ; quá nhiều epoch → overfitting preference.

---

## Toán ứng dụng "ngoài bảng"

Sau khi vững nền (1-7), những mảng sau **thường có ROI cao hơn** so với học (10)(11)(12):

### A. Statistical Learning Theory
- **Nội dung:** PAC learning, VC dimension, Rademacher complexity, generalization bound, uniform convergence.
- **Tại sao:** trả lời "vì sao mô hình generalize?". Lưu ý: bound cổ điển vacuous trên DL; 2020-2026 có hướng PAC-Bayes, NTK-based bound đỡ hơn.
- **Tài liệu:** Shalev-Shwartz & Ben-David — "Understanding Machine Learning".
- **Tự kiểm:** derive Hoeffding bound; tính VC-dim của linear classifier; giải thích vì sao DL bound cổ điển vacuous.

### B. Reinforcement Learning Math
- **Nội dung:** MDP, Bellman equation, policy gradient theorem, TD learning, exploration-exploitation, GAE, importance sampling.
- **Tại sao:** RLHF, GRPO, reasoning model (o1/R1), agent, robotics. Cực hot 2026.
- **Tài liệu:** Sutton & Barto — "Reinforcement Learning: An Introduction" (free PDF). Bổ sung: Spinning Up (OpenAI), CleanRL repo.
- **Tự kiểm:** derive policy gradient theorem; implement REINFORCE + baseline; giải thích GAE λ trade-off bias/variance; derive PPO clipped objective.

### C. Convex Analysis nâng cao
- **Nội dung:** subdifferential, proximal operator, ADMM, mirror descent, Bregman divergence.
- **Tại sao:** Optimization research, sparse methods, một số optimizer LLM (Muon) liên quan.
- **Tài liệu:** Boyd & Vandenberghe "Convex Optimization" (sâu hơn).
- **Tự kiểm:** derive proximal của L1 (soft-thresholding); giải thích mirror descent = GD trên dual space.

### D. Causal Inference
- **Nội dung:** do-calculus, counterfactual, instrumental variable, DAG, front/back-door criterion.
- **Tại sao:** Ngách đang lên, ít người làm AI biết. Quan trọng cho evaluation rigorous + debias LLM.
- **Tài liệu:** Pearl — "Causality" hoặc "The Book of Why". Bổ sung: "Causal Inference: The Mixtape" (Cunningham, free).
- **Tự kiểm:** phân biệt p(y|x) và p(y|do(x)); giải thích Simpson's paradox bằng DAG.

### E. Game Theory
- **Nội dung:** Nash equilibrium, minimax, mechanism design, no-regret learning.
- **Tại sao:** GAN, multi-agent RL, alignment, self-play (AlphaZero, debate).
- **Tài liệu:** Osborne — "An Introduction to Game Theory".
- **Tự kiểm:** tính Nash cho rock-paper-scissors; giải thích minimax = saddle-point optimization.

### F. Computational Complexity
- **Nội dung:** P, NP, approximation, hardness, randomized algorithm.
- **Tại sao:** Hiểu khi nào bài toán không scalable, lý do cần heuristic.
- **Tự kiểm:** chứng minh attention O(n²) là tight không? Linear attention đánh đổi gì?

---

## Bẫy meta khi học toán cho AI

Bẫy theo từng mảng đã ở trong section của mảng đó. Mục này chỉ ghi bẫy **xuyên mảng** — về cách học, không về nội dung.

1. **"Học hết toán rồi mới làm"** → không bao giờ đủ. Làm song song, học theo trigger.
2. **Học từ sách thuần lý thuyết** → quên ngay. Implement bắt buộc; intuition đến từ ngón tay.
3. **Học mảng cao trước khi vững mảng thấp.** Topology trước calculus = lãng phí. Theo thứ tự ưu tiên trong bảng.
4. **Tin "phải có PhD math"** → sai. Top engineer ở frontier lab phần lớn học toán theo nhu cầu, không học hệ thống từ đầu.
5. **Bỏ qua (6) Numerical** → debug NaN cả đời mà không hiểu root cause.
6. **Học rời rạc mỗi mảng, không kết nối** → quên. Một dự án dùng 3-4 mảng cùng lúc → ghim sâu hơn 6 tháng đọc sách.
7. **Đặt research lên bệ thờ** → tự ti. Engineer giỏi cần toán không kém researcher, chỉ khác mặt chiều sâu vs chiều rộng.
8. **Không re-evaluate path mỗi 3 tháng** → đi đường cũ vì sunk cost dù mục tiêu đã đổi.
9. **"Đọc 50 paper rồi mới reproduce"** → reading-without-doing trap. Reproduce 1 paper > đọc 20.

---

## Lộ trình 12 tháng đề xuất

**Giả định nền tảng:** đã có (1)(2)(3)(4) ở mức "biết dùng" — implement được MLP, hiểu backprop, biết Gaussian, biết SGD/Adam. Chưa vững (5) Info Theory, (6) Numerical, (7) Discrete & Graph; chưa đụng 8-13.

Roadmap chia theo **mục tiêu cuối**, không one-size-fits-all. Pick một path, đừng nhảy giữa các path.

### Path 1 — Engineer (production, infra, applied)
*Đích: train/serve LLM ở scale, debug hiệu năng, ship feature.*

| Tháng | Toán | Skill | Deliverable |
|---|---|---|---|
| 1-3 | Vá (5) Info Theory + (6) Numerical sâu | Mixed precision (BF16/FP8), gradient clipping, profiling (PyTorch Profiler, Nsight) | Blog/repo: "Numerical pitfalls in LLM training" |
| 4-6 | (1) sâu hơn: low-rank, Kronecker; (4) optim: LR schedule, optimizer state | Distributed (DDP/FSDP/ZeRO), CUDA cơ bản (1 kernel: fused softmax hoặc layernorm) | Train ≥1B params trên multi-GPU, log scaling curve |
| 7-9 | (13) LLM math: FlashAttention v3, RoPE, GQA, KV cache | Inference stack (vLLM/SGLang), quantization (GPTQ/AWQ) | Serve mô hình production với SLA latency/throughput đo được |
| 10-12 | (13) tiếp: speculative decoding, MoE | Eval harness, regression test cho LLM | One end-to-end feature: từ data → train → eval → serve |

### Path 2 — Research (papers, novel methods)
*Đích: đọc paper fluent, reproduce + extend, contribute novel idea.*

| Tháng | Toán | Skill | Deliverable |
|---|---|---|---|
| 1-3 | Vá (5) Info Theory; (4) optim sâu hơn (convergence, sharpness) | Re-implement transformer/VAE from scratch, đọc 1 paper/tuần | Blog: "Information Theory in modern DL" + 12 paper summary |
| 4-6 | Toán theo subfield: generative → (8) ODE/SDE; theory → (A) SLT; geometric → (10)(11); align/RL → (B) | Reproduce 1 paper "vừa sức" trong subfield, không copy code | Repo reproduced fully + writeup khó khăn gặp |
| 7-9 | Đi sâu mảng phụ subfield (vd. diffusion: học (8) đầy đủ; RLHF: học (B) đầy đủ) | Đọc 1 paper/tuần + reproduce 1 baseline mỗi tháng | Identify 2-3 limitation của paper đã reproduce |
| 10-12 | Theo nhu cầu paper bạn đang viết | Design 1 experiment nhỏ test 1 hypothesis cụ thể | Workshop-quality writeup, submit nếu kết quả tốt |

### Path 3 — Applied / Domain ML (science, finance, health, etc.)
*Đích: dùng ML giải bài toán domain cụ thể, không nhất thiết train từ đầu.*

| Tháng | Toán | Skill | Deliverable |
|---|---|---|---|
| 1-3 | (3) Probability sâu hơn (Bayesian, hypothesis testing); (5) Info Theory cơ bản | Fine-tuning workflow (LoRA, QLoRA), prompt engineering có rigor | 1 fine-tuned model trên domain dataset, eval đầy đủ |
| 4-6 | (D) Causal Inference; (3) uncertainty quantification | Eval design, A/B test, calibration | Report: domain task với uncertainty + causal claim defensible |
| 7-9 | Toán domain-specific (vd. health: survival analysis; finance: time-series, stochastic calculus) | Domain integration (data pipeline, MLOps) | End-to-end domain pipeline với stakeholder feedback |
| 10-12 | Theo nhu cầu | Productionization, monitoring drift | System chạy production với metric domain-relevant |

### Nguyên tắc xuyên suốt (cả 3 path)

- **Không học mảng (9)(10)(11)(12) trong 12 tháng đầu** trừ khi path bạn pick yêu cầu rõ (Path 2 + subfield geometric/theory).
- **Re-evaluate mỗi 3 tháng:** path còn phù hợp không? Nếu mục tiêu đổi, đổi path — đừng cố hoàn thành path cũ vì sunk cost.
- **Toán học theo trigger:** gặp bài toán cần X → học X. Không học X "để dành".
- **Deliverable trước reading:** xong deliverable mới được đọc thêm paper mới. Tránh perpetual learning trap.

---

## Glossary VIE-EN

| Tiếng Việt | English | Viết tắt |
|---|---|---|
| Đại số tuyến tính | Linear Algebra | LA |
| Giải tích | Calculus | — |
| Đạo hàm | Derivative | — |
| Gradient | Gradient | ∇ |
| Đạo hàm riêng | Partial Derivative | ∂ |
| Ma trận Jacobi | Jacobian | J |
| Ma trận Hessian | Hessian | H |
| Quy tắc dây chuyền | Chain Rule | — |
| Lan truyền ngược | Backpropagation | backprop |
| Trị riêng | Eigenvalue | λ |
| Vector riêng | Eigenvector | v |
| Phân tích giá trị kỳ dị | Singular Value Decomposition | SVD |
| Xác định dương | Positive Definite | PD |
| Nửa xác định dương | Positive Semi-Definite | PSD |
| Phân phối | Distribution | — |
| Phân phối Gauss | Gaussian Distribution | 𝒩 |
| Kỳ vọng | Expectation | E |
| Phương sai | Variance | Var |
| Hiệp phương sai | Covariance | Cov |
| Ước lượng hợp lý cực đại | Maximum Likelihood Estimation | MLE |
| Ước lượng hậu nghiệm cực đại | Maximum A Posteriori | MAP |
| Định lý giới hạn trung tâm | Central Limit Theorem | CLT |
| Suy luận biến phân | Variational Inference | VI |
| Cận dưới hợp lý | Evidence Lower Bound | ELBO |
| Entropy | Entropy | H |
| Entropy chéo | Cross-Entropy | H(p,q) |
| Phân kỳ KL | Kullback-Leibler Divergence | D_KL |
| Thông tin tương hỗ | Mutual Information | I |
| Tối ưu | Optimization | — |
| Lồi | Convex | — |
| Không lồi | Non-convex | — |
| Tốc độ học | Learning Rate | lr |
| Mô hình sinh | Generative Model | — |
| Mô hình khuếch tán | Diffusion Model | — |
| Mạng nơ-ron đồ thị | Graph Neural Network | GNN |
| Đa tạp | Manifold | — |
| Không gian tiếp tuyến | Tangent Space | — |
| Phép tịnh tiến/quay (group) | Translation / Rotation | — |
| Đẳng biến / Bất biến | Equivariant / Invariant | — |
| Mô hình không gian trạng thái | State Space Model | SSM |
| Hỗn hợp chuyên gia | Mixture of Experts | MoE |
| Lượng tử hoá (mô hình) | Quantization (PTQ/QAT) | — |
| Giải mã suy đoán | Speculative Decoding | — |
| Tính toán lúc suy luận | Test-Time Compute | TTC |
| Mô hình thưởng theo bước | Process Reward Model | PRM |
| Học tăng cường từ feedback người | Reinforcement Learning from Human Feedback | RLHF |
| Tối ưu sở thích trực tiếp | Direct Preference Optimization | DPO |

---

## Kết

Tài liệu này là **bản đồ**, không phải **lộ trình bắt buộc**. Mỗi người có background khác nhau, mục tiêu khác nhau. Ba nguyên tắc nên giữ:

1. **Học theo nhu cầu thực tế.** Có dự án → cần toán nào → học toán đó.
2. **Implement, đừng chỉ đọc.** Math intuition đến từ ngón tay, không từ mắt.
3. **Pick một path, re-evaluate mỗi 3 tháng.** Path 1 (Engineer) / Path 2 (Research) / Path 3 (Applied) — không nhảy giữa các path vì FOMO.

Nếu bạn đã có (1)(2)(3)(4) ở mức "biết dùng" và đang chuẩn bị bước vào LLM era: trọng tâm 6 tháng tới nên là **vá (5) Info Theory + (6) Numerical + (13) LLM math** — chứ không phải đua học (10)(11)(12) hay measure theory.

> *"In theory, theory and practice are the same. In practice, they are not."*
