# Các Mô Hình Toán Học Nền Tảng trong Machine Learning

> Một "mô hình" trong Học máy thực chất là sự kết hợp của nhiều yếu tố: **phương trình giả thuyết** (hypothesis), **hàm mất mát** (loss function), và **thuật toán tối ưu** (optimizer). Chỉ cần thay đổi một hàm số, thêm một tham số, hoặc tổ hợp kết quả của nhiều mô hình, ta đã tạo ra một mô hình mới. Mỗi ngày, các nhà nghiên cứu trên thế giới vẫn đang công bố thêm hàng chục biến thể mới.
>
> Tuy nhiên, toàn bộ "vũ trụ" Machine Learning khổng lồ đó đều được xây dựng dựa trên khoảng **20+ mô hình toán học nền tảng**. Từ những viên gạch cốt lõi này, người ta mới phát triển ra các thuật toán phức tạp hơn.

---

## 1. Học có Giám sát — Supervised Learning

*Học ánh xạ f: X → Y từ dữ liệu đầu vào đã có nhãn (đáp án).*

| # | Mô hình | Ý tưởng cốt lõi | Toán nền tảng |
|---|---------|-----------------|---------------|
| 1 | **Linear Regression** | Dùng phương trình đường thẳng / siêu mặt phẳng (ŷ = Wx + b) để dự đoán giá trị liên tục (giá nhà, nhiệt độ). | Phương trình chuẩn tắc (normal equation), gradient descent |
| 2 | **Logistic Regression** | Dùng hàm Sigmoid σ(z) = 1/(1+e⁻ᶻ) để bóp giá trị về [0, 1] → xác suất phân loại (spam hay không). | Cross-entropy loss, MLE |
| 3 | **Support Vector Machine (SVM)** | Tìm siêu mặt phẳng trong không gian nhiều chiều có **margin tối đa** ngăn cách các lớp dữ liệu. | Hinge loss, điều kiện KKT, kernel trick |
| 4 | **Decision Tree** | Đặt câu hỏi Có/Không liên tục, chia nhỏ dữ liệu theo tiêu chí giảm độ nhiễu loạn thông tin. | Entropy, Gini impurity |
| 5 | **Naive Bayes** | Dự đoán P(y\|x) dựa trên Định lý Bayes, giả định các đặc trưng độc lập có điều kiện. | Bayes' theorem, MLE |
| 6 | **K-Nearest Neighbors (KNN)** | Dự đoán bằng "bầu chọn" của K điểm dữ liệu gần nhất — lazy learner, không có giai đoạn huấn luyện. | Khoảng cách Euclid / Manhattan |

### Kỹ thuật Ensemble (vẫn là Supervised Learning)

*Gộp nhiều mô hình cơ bản lại với nhau để tạo ra một mô hình mạnh hơn tổng các thành phần. Đây là **kỹ thuật tổ hợp**, không phải paradigm học riêng biệt.*

| # | Mô hình | Ý tưởng cốt lõi | Toán nền tảng |
|---|---------|-----------------|---------------|
| 7 | **Random Forest** | Tạo hàng trăm Decision Tree khác nhau (bagging + lấy mẫu đặc trưng ngẫu nhiên), kết quả cuối là trung bình / bầu chọn. | Variance reduction, bootstrap sampling |
| 8 | **Gradient Boosting** (XGBoost, LightGBM) | Xây các mô hình **nối tiếp** nhau; mỗi mô hình sau dùng gradient để sửa lỗi sai của mô hình trước. | Functional gradient descent, Taylor bậc 2 |

---

## 2. Học không Giám sát — Unsupervised Learning

*Tự động tìm ra cấu trúc ẩn bên trong dữ liệu mà không cần nhãn.*

| # | Mô hình | Ý tưởng cốt lõi | Toán nền tảng |
|---|---------|-----------------|---------------|
| 9 | **K-Means Clustering** | Gom dữ liệu thành K cụm bằng cách lặp: gán điểm → cập nhật trọng tâm (centroid). Cần chọn K trước. | Lloyd's algorithm, Voronoi partitions |
| 10 | **DBSCAN** | Clustering dựa trên **mật độ** — tự phát hiện số cụm, xử lý được cluster hình dạng bất kỳ và loại bỏ nhiễu (noise). | ε-neighborhood, minPts, core/border/noise points |
| 11 | **Hierarchical Clustering** | Xây cây phân cấp (dendrogram) bằng cách liên tục gộp cặp cụm gần nhất — không cần chọn K trước. | Linkage criteria (single, complete, Ward) |
| 12 | **GMM** (Gaussian Mixture Model) | Soft clustering — mỗi điểm thuộc về nhiều cụm với xác suất khác nhau, mỗi cụm là một phân phối Gaussian. | EM algorithm, MLE, latent variables |
| 13 | **PCA** (Principal Component Analysis) | "Ép" dữ liệu từ không gian nhiều chiều xuống ít chiều hơn mà giữ lại phương sai lớn nhất. | Eigendecomposition, SVD, ma trận hiệp phương sai |

---

## 3. Mạng Nơ-ron & Học sâu — Deep Learning

*Xếp chồng các phép biến đổi tuyến tính + hàm kích hoạt phi tuyến thành nhiều lớp (layer). Số lượng kiến trúc gần như vô hạn vì có thể tự do tổ hợp.*

| # | Mô hình | Ý tưởng cốt lõi | Toán nền tảng |
|---|---------|-----------------|---------------|
| 14 | **Multi-Layer Perceptron (MLP)** | Mạng nơ-ron cơ bản nhất: chuỗi phép nhân ma trận xen kẽ hàm phi tuyến (ReLU, tanh). | Chain rule (backpropagation) |
| 15 | **CNN** (Convolutional Neural Network) | Dùng phép toán **tích chập** để trích xuất đặc trưng không gian — xuất sắc với hình ảnh. | Cross-correlation, pooling, stride/padding |
| 16 | **RNN / LSTM / GRU** | Chứa vòng lặp toán học cho mô hình "có trí nhớ" — chuyên xử lý dữ liệu tuần tự (văn bản, chuỗi thời gian). | BPTT, cơ chế cổng (forget/input/output gates) |
| 17 | **Transformer** | Kiến trúc nền tảng của ChatGPT, Gemini, Claude. Dùng cơ chế **Self-Attention** — tính toán mức độ liên quan giữa mọi phần tử trong chuỗi với nhau. | Attention = softmax(QKᵀ/√dₖ)V, positional encoding |

---

## 4. Mô hình Sinh — Generative Models

*Học phân phối dữ liệu p(x) để **tạo ra mẫu mới** (ảnh, văn bản, âm thanh) chưa từng tồn tại trong tập huấn luyện.*

| # | Mô hình | Ý tưởng cốt lõi | Toán nền tảng |
|---|---------|-----------------|---------------|
| 18 | **VAE** (Variational Autoencoder) | Encoder nén dữ liệu vào không gian ẩn (latent space), Decoder giải nén lại. Học được phân phối ẩn liên tục → sinh mẫu mới bằng cách sampling. | ELBO, KL divergence, reparameterization trick |
| 19 | **GAN** (Generative Adversarial Network) | Trò chơi đối kháng: Generator tạo dữ liệu giả, Discriminator phân biệt thật/giả — hai bên đấu nhau đến khi Generator tạo ra dữ liệu không thể phân biệt. | Minimax game: min_G max_D, Nash equilibrium |
| 20 | **Diffusion Models** (DDPM) | Từ từ thêm nhiễu Gaussian vào ảnh cho đến khi thành noise thuần túy (forward), rồi học cách **đảo ngược** quá trình đó để sinh ảnh từ noise (reverse). Nền tảng của DALL·E, Stable Diffusion. | Markov chain, variational lower bound, score matching |

---

## 5. Học Tăng cường — Reinforcement Learning

*Agent tự học thông qua vòng lặp: quan sát trạng thái → chọn hành động → nhận phần thưởng → cập nhật chiến lược. Mục tiêu: tối đa tổng phần thưởng dài hạn.*

| # | Mô hình | Ý tưởng cốt lõi | Toán nền tảng |
|---|---------|-----------------|---------------|
| 21 | **Q-Learning** (Value-based) | Học hàm giá trị Q(s, a) — ước lượng phần thưởng kỳ vọng khi thực hiện hành động a tại trạng thái s. Agent chọn hành động có Q cao nhất. | MDP (Markov Decision Process), Bellman equation, TD learning |
| 22 | **Policy Gradient** (REINFORCE, PPO) | Tối ưu **trực tiếp** policy π(a\|s) bằng gradient ascent trên hàm mục tiêu phần thưởng — không cần ước lượng Q. Approach khác bản chất so với Q-Learning. | ∇J = E[∇ log π(a\|s) · Gₜ], advantage estimation |

> **Lưu ý:** MDP (Markov Decision Process) là **framework toán học** mô tả bài toán RL (trạng thái, hành động, phần thưởng, xác suất chuyển tiếp) — không phải model. Q-Learning và Policy Gradient là hai họ thuật toán chính để giải MDP.

---

## Tóm tắt: 5 Trụ cột Toán học của Machine Learning

| Trụ cột | Vai trò trong ML | Ví dụ |
|---------|-----------------|-------|
| **Đại số tuyến tính** (Linear Algebra) | Biểu diễn dữ liệu bằng ma trận & vector; ngôn ngữ nội tại của mọi mạng nơ-ron. | Nhân ma trận trong MLP, SVD trong PCA, attention QKᵀ |
| **Giải tích** (Calculus) | Tính đạo hàm để biết hướng giảm sai số — nền tảng của backpropagation. | Chain rule, Jacobian, gradient descent |
| **Xác suất & Thống kê** (Probability & Statistics) | Suy luận dưới sự không chắc chắn; ước lượng tham số từ dữ liệu. | Bayes' theorem, MLE/MAP, cross-entropy |
| **Tối ưu hóa** (Optimization) | Tìm tham số tối ưu cho mô hình — SGD, Adam, convex vs non-convex, constrained optimization. Là lĩnh vực riêng, rộng hơn "ứng dụng của Calculus". | SGD, Adam, KKT (SVM), EM algorithm |
| **Lý thuyết thông tin** (Information Theory) | Đo lường lượng thông tin, sự khác biệt giữa các phân phối — thiết yếu cho loss function và generative models. | Entropy, KL divergence, mutual information, ELBO |

---

> **Lời khuyên:** Không cần học hàng ngàn mô hình. Nắm vững bản chất toán học của khoảng **10–15 thuật toán nền tảng** (Linear / Logistic Regression, Decision Tree, Random Forest, K-Means, PCA, MLP, CNN cơ bản…) là đã đủ công cụ giải quyết **hơn 80% các bài toán thực tế**.
